const cells = document.querySelectorAll('.cell');
const resetButton = document.getElementById('reset');
const resultScreen = document.getElementById('resultScreen');
const resultMessage = document.getElementById('resultMessage');
const newGameButton = document.getElementById('newGame');
const boardContainer = document.getElementById('board');

let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
let isGameOver = false;

const winPatterns = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

function handleClick(event) {
  const index = event.target.getAttribute('data-index');

  if (board[index] === '' && !isGameOver) {
    board[index] = currentPlayer;
    event.target.textContent = currentPlayer;
    if (checkWin()) {
      showResult(`Player ${currentPlayer} wins!`);
      isGameOver = true;
    } else if (board.every(cell => cell !== '')) {
      showResult('It\'s a draw!');
      isGameOver = true;
    } else {
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
  }
}

function checkWin() {
  return winPatterns.some(pattern => {
    return pattern.every(index => board[index] === currentPlayer);
  });
}

function resetGame() {
  board = ['', '', '', '', '', '', '', '', ''];
  currentPlayer = 'X';
  isGameOver = false;
  cells.forEach(cell => {
    cell.textContent = '';
  });
}

function showResult(message) {
  resultMessage.textContent = message;
  resultScreen.style.display = 'block';
  boardContainer.style.display = 'none';  // Hide the board when showing the result
}

function startNewGame() {
  resetGame();
  resultScreen.style.display = 'none';
  boardContainer.style.display = 'grid';  // Show the board again for new game
}

cells.forEach(cell => cell.addEventListener('click', handleClick));
resetButton.addEventListener('click', resetGame);
newGameButton.addEventListener('click', startNewGame);
